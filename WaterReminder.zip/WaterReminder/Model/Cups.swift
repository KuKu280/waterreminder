//
//  Cups.swift
//  WaterReminder
//
//  Created by Admin on 18/12/2019.
//  Copyright © 2019 Admin. All rights reserved.
//

import Foundation

struct Cups {
    
    var imageName:String
    var title:String {
       return String(ml) + "ML"
    }
    var ml:Float
    

    init(ml:Float,imageName:String) {
        self.ml = ml
        
        self.imageName = imageName
    }
}
