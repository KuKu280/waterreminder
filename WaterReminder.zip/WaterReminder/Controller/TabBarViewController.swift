//
//  TabBarViewController.swift
//  WaterReminder
//
//  Created by Admin on 15/12/2019.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

class TabBarViewController: UITabBarController {
    
     var waterLiter:String?

    override func viewDidLoad() {
        super.viewDidLoad()

        
        let homeVC = self.children[1] as! HomeViewController
        homeVC.waterLiter = self.waterLiter
        self.selectedIndex = 1
    }
    

   

}
