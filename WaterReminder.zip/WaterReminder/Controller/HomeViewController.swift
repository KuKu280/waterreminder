//
//  HomeViewController.swift
//  WaterReminder
//
//  Created by Admin on 15/12/2019.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController,CupDataDelegate, UITableViewDelegate,UITableViewDataSource{
   
    var waterLiter:String?
    var cupsProduct = [Cups]()
    var userCups = [Cups]()

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var progressView: UIProgressView!
    @IBOutlet weak var dailyLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    
   
    var delegate:CupDataDelegate?
    let progress = Progress(totalUnitCount: 10)
//    var totalDrinkingwater = 300
//    var targetAmount = 2000

    override func viewDidLoad() {
        super.viewDidLoad()
        let tabbar = self.tabBarController
        let cupVC = tabbar?.viewControllers?[2]  as! CupsViewController
        cupVC.delegate = self
        
        tableView.delegate = self
        tableView.dataSource = self
        progressView.setProgress(0, animated: false)
        
        dailyLabel.text = "\(waterLiter ?? "")"

        
    }
    
    func setData(cups: Cups) {
        DataService.instance.addCups(newCup: cups)
        tableView.reloadData()
        
       }
   

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return DataService.instance.getCups().count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CupCell", for: indexPath) as! CupTableViewCell
        let cups = DataService.instance.getCups()[indexPath.row]
        
        cell.setData(cups: cups)
    
       return cell
    }
    
    @IBAction func addBtn(_ sender: UIButton) {
        
        
        var totalDrinkingWater = DataService.instance.userCups.count
        var targetAmount = 2000
        progressView.progress = ( Float(totalDrinkingWater) / Float(targetAmount)) * 100
       
        
        self.titleLabel.text = "\(Int(self.progress.fractionCompleted))%"
        
        
    }
        
            
    
//    @objc func updateUI(){
//       
//    }
    

}

