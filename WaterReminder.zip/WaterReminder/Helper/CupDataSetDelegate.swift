//
//  CupDataSetDelegate.swift
//  WaterReminder
//
//  Created by Admin on 19/12/2019.
//  Copyright © 2019 Admin. All rights reserved.
//

import Foundation

protocol CupDataDelegate {
    func setData(cups:Cups)
}
