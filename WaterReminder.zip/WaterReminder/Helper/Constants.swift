//
//  Constants.swift
//  WaterReminder
//
//  Created by Admin on 18/12/2019.
//  Copyright © 2019 Admin. All rights reserved.
//

import Foundation

struct Constants {
    struct Storyboard {
        static let cupImageView = "HomeViewController"
    }
    
   
}

